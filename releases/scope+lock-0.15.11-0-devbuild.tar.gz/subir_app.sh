#!/bin/bash

if [[ $BASH_ARGC > 0 ]]; then
  RPIP="$1"
else
  RPIP="rp-f01d89.local"
fi

# rp-xxxxxx.local

RPOPTS="-l root"
CONTROLLERHF="controllerhf.so"


ssh $RPIP $RPOPTS "PATH_REDPITAYA=/opt/redpitaya /boot/sbin/rw ; rm -rf /opt/redpitaya/www/apps/scope+lock ; mkdir -p /opt/redpitaya/www/apps/scope+lock ; mkdir -p /root/py"
echo "

---------------------

"

scp $RPSCP -r scope+lock/*  root@$RPIP:/opt/redpitaya/www/apps/scope+lock/

echo "

---------------------

"


scp -r scope+lock/RP_py/*.py  root@$RPIP:/root/py/


echo "

Si no tiró errores, solo hay que recargar la APP en el navegador.

"

echo "Presione ENTER para finalizar"

read

